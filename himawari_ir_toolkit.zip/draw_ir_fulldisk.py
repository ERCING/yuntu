"""
IR 圆盘图绘制脚本
使用 pycontrails 从 NOAA S3 读取 Himawari-9 B14 红外波段数据，
配合 mycolor.py 中的自定义色阶绘制全圆盘红外云图。

用法:
    python draw_ir_fulldisk.py                          # 默认: IR-CC, 最新数据
    python draw_ir_fulldisk.py --time "2025-07-24T06:00" # 指定时间
    python draw_ir_fulldisk.py --scheme IR-BD            # 指定色阶
    python draw_ir_fulldisk.py --scheme ALL               # 画所有色阶
    python draw_ir_fulldisk.py --list                     # 列出可用色阶
"""

import sys
import os
import argparse
import warnings
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import cartopy.crs as ccrs
import cartopy.feature as cfeature

warnings.filterwarnings('ignore')

# 导入自定义色阶
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mycolor import color_map, my_color_map

# ============================================================
# 配置参数
# ============================================================
# 默认降采样因子（1=原生 5500x5500，2=2750x2750，4=1375x1375）
DEFAULT_DOWNSAMPLE = 1

# 可用色阶列表
IR_SCHEMES = ['IR-BD', 'IR-CC', 'IR-CA', 'IR-OTT', 'IR-RAMMB', 'IR-RBTOP']

# 默认时间
DEFAULT_TIME = "2025-07-24T06:00:00"


def draw_ir_fulldisk(time_str=DEFAULT_TIME, scheme='IR-CC',
                     out_path=None, dpi=150, downsample=DEFAULT_DOWNSAMPLE):
    """
    下载并绘制 Himawari-9 B14 红外全圆盘图

    Parameters
    ----------
    time_str : str
        UTC 时间字符串，格式 "YYYY-MM-DDTHH:MM:SS"
    scheme : str
        色阶名称: IR-BD, IR-CC, IR-CA, IR-OTT, IR-RAMMB, IR-RBTOP
    out_path : str or None
        输出路径，None 则自动生成
    dpi : int
        输出图片分辨率
    downsample : int
        降采样因子，1=原生 5500x5500，2=半分辨率，4=1/4 分辨率
    """
    from pycontrails.datalib.himawari import Himawari

    print(f"[1/4] 下载 Himawari-9 B14 全圆盘数据...")
    print(f"      时间: {time_str}")
    print(f"      区域: 全圆盘 (FLDK)")
    print(f"      波段: B14 (11.2μm 红外窗区)")

    hima = Himawari(region="F", bands=("B14",))
    da = hima.get(time_str)
    print(f"      原始维度: {da.shape}")

    # 降采样
    if downsample > 1:
        print(f"[2/4] 降采样 (因子={downsample})...")
        da_sub = da.isel(x=slice(None, None, downsample),
                         y=slice(None, None, downsample))
    else:
        print(f"[2/4] 使用原生分辨率...")
        da_sub = da
    print(f"      降采样后: {da_sub.shape}")

    # 提取亮温数据 (K -> °C)
    bt_k = da_sub.values[0]  # shape: (ny, nx)
    bt_c = bt_k - 273.15

    # 构建投影坐标: x/y 是扫描角(弧度), 乘以卫星高度得到投影坐标(米)
    proj4_str = da.attrs['crs']
    h = 35785863.0  # 卫星高度 (米)
    x_scan = da_sub['x'].values  # 扫描角 (弧度)
    y_scan = da_sub['y'].values
    x_proj = h * x_scan  # 投影坐标 (米)
    y_proj = h * y_scan

    # 获取色阶
    cmap, norm = my_color_map(scheme)
    vmin = float(norm.vmin)
    vmax = float(norm.vmax)

    print(f"[3/4] 绑制全圆盘 IR 云图 ({scheme})...")
    print(f"      亮温范围: {np.nanmin(bt_c):.1f} ~ {np.nanmax(bt_c):.1f} °C")
    print(f"      色阶范围: {vmin:.1f} ~ {vmax:.1f} °C")

    # 创建绑图 - 使用 Geostationary 投影
    src_crs = ccrs.Geostationary(central_longitude=140.7,
                                  satellite_height=35785863.0,
                                  sweep_axis='x')
    src_extent = (x_proj.min(), x_proj.max(), y_proj.min(), y_proj.max())

    fig = plt.figure(figsize=(14, 14))
    ax = fig.add_subplot(1, 1, 1, projection=src_crs)

    # 绘制填色图 (使用 imshow + extent 方式，性能更好)
    cf = ax.imshow(bt_c, extent=src_extent, origin='upper',
                   cmap=cmap, norm=norm, interpolation='none')

    # 添加海岸线和国界
    ax.coastlines(resolution='50m', color='black', linewidth=0.8)
    ax.add_feature(cfeature.BORDERS, edgecolor='black', linewidth=0.5)

    # 添加网格线
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.3,
                      color='gray', alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False

    # 标题
    time_label = time_str.replace('T', ' ').replace(':00:00', ':00')
    ax.set_title(f'Himawari-9 IR Full Disk  B14 (11.2μm)\n'
                 f'{time_label} UTC  |  Color Scheme: {scheme}',
                 fontsize=16, fontweight='bold')

    # 添加色标
    cbar = fig.colorbar(cf, ax=ax, shrink=0.75, pad=0.02,
                        orientation='horizontal')
    cbar.set_label('Brightness Temperature (°C)', fontsize=12)

    plt.tight_layout()

    if out_path is None:
        out_path = f'/workspace/himawari_fulldisk_{scheme}.png'

    print(f"[4/4] 保存图片: {out_path}")
    fig.savefig(out_path, dpi=dpi, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    plt.close(fig)
    print(f"      完成! 文件大小: {os.path.getsize(out_path) / 1024:.1f} KB")
    return out_path


def list_schemes():
    """列出所有可用色阶"""
    print("可用 IR 色阶方案:")
    print("-" * 50)
    for name in IR_SCHEMES:
        data = color_map[name]
        temps = data["Temperature"]
        colors = data["Color"]
        print(f"  {name:12s}  温度范围: {temps.min():6.1f} ~ {temps.max():6.1f} °C  "
              f"({len(temps)} 个断点)")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='IR 圆盘图绘制工具')
    parser.add_argument('--time', type=str, default=DEFAULT_TIME,
                        help=f'UTC时间 (格式: YYYY-MM-DDTHH:MM:SS), 默认: {DEFAULT_TIME}')
    parser.add_argument('--scheme', type=str, default='IR-CC',
                        help=f'色阶方案: {", ".join(IR_SCHEMES)} 或 ALL, 默认: IR-CC')
    parser.add_argument('--list', action='store_true',
                        help='列出所有可用色阶')
    parser.add_argument('--dpi', type=int, default=150,
                        help='输出分辨率, 默认: 150')
    parser.add_argument('--out', type=str, default=None,
                        help='输出路径')
    parser.add_argument('--downsample', type=int, default=DEFAULT_DOWNSAMPLE,
                        help=f'降采样因子: 1=原生 5500x5500, 2=半分辨率, 4=1/4分辨率, 默认: {DEFAULT_DOWNSAMPLE}')

    args = parser.parse_args()

    if args.list:
        list_schemes()
        sys.exit(0)

    if args.scheme.upper() == 'ALL':
        for s in IR_SCHEMES:
            print(f"\n{'=' * 60}")
            print(f"绘制色阶: {s}")
            print(f"{'=' * 60}")
            try:
                draw_ir_fulldisk(time_str=args.time, scheme=s, dpi=args.dpi,
                                 downsample=args.downsample)
            except Exception as e:
                print(f"  [错误] {s}: {e}")
    else:
        if args.scheme not in IR_SCHEMES:
            print(f"错误: 未知色阶 '{args.scheme}'")
            print(f"可用: {', '.join(IR_SCHEMES)}")
            sys.exit(1)
        draw_ir_fulldisk(time_str=args.time, scheme=args.scheme,
                         out_path=args.out, dpi=args.dpi,
                         downsample=args.downsample)